# install.py - installer for the BelchertownWxFeeds extension.
# Copyright 2020-2099 Garry Lockyer - Garry@lockyer.ca.
# Distributed under the terms of the GNU Public License (GPLv3).

from setup import ExtensionInstaller

def loader():
    return BelchertownWxFeedsInstaller()

class BelchertownWxFeedsInstaller(ExtensionInstaller):
    def __init__(self):
        super(BelchertownWxFeedsInstaller, self).__init__(
            version="1.14",
            name='BelchertownWxFeeds',
            description='Extension to the WeeWx Belchertown Skin to access numerous RSS/Atom/XML Feeds',
            author="Garry Lockyer",
            author_email="Garry@lockyer.ca",
            config={
                       'StdReport': {

                           'Belchertown': {

                               'CheetahGenerator': {

                                   'search_list_extensions': 'user.belchertown.getData, user.BelchertownWxFeeds.WxFeedsSearch'
                               },

                               'WxFeeds': {

                                   'initialize_belchertown_include_file_index_hook_after_station_info': 'yes',
                                   'belchertown_include_file': 'index_hook_after_station_info.inc',
                                   'include_file_sequence': 'only',

                                   'add_back_to_top_button': 'yes',

                                   'Environment Canada': {

                                       'Citys': {

                                           'alerts_first': 'yes',
                                           'inline_forecast': 'yes',
                                           'get_weather': 'yes',
                                           'get_alerts': 'no',

                                           'Osoyoos, BC': {

                                               'feed_url': 'https://weather.gc.ca/rss/city/bc-69_e.xml'
                                           },
                                       },
                                   },
                               },
                           },
                       },
                       'Logging': {
                           'Loggers': {
                               'user.BelchertownWxFeeds': {
                                   'level': 'WARNING',
                                   'handlers': 'syslog',
                                   'propagate': '0'
                               }
                           }
                       }
                   },

            files=[('bin/user', ['bin/user/BelchertownWxFeeds.py'
                                ]
                    ),
                   ('skins/Belchertown', ['skins/Belchertown/BelchertownWxFeeds-READ-ME',
                                          'skins/Belchertown/BelchertownWxFeeds-Sample-WxFeeds'
                                         ]
                    ),
                   ('skins/Belchertown/images', ['skins/Belchertown/images/WxFeeds-checklist.png',
                                                 'skins/Belchertown/images/WxFeeds-current-planned-cone.png',
                                                 'skins/Belchertown/images/WxFeeds-future-planned-cone.png',
                                                 'skins/Belchertown/images/WxFeeds-google-map.png',
                                                 'skins/Belchertown/images/WxFeeds-incident.png',
                                                 'skins/Belchertown/images/WxFeeds-map.png',
                                                 'skins/Belchertown/images/WxFeeds-map-marker.png',
                                                 'skins/Belchertown/images/WxFeeds-play.png',
                                                 'skins/Belchertown/images/WxFeeds-refresh.png',
                                                 'skins/Belchertown/images/WxFeeds-road-condition.png',
                                                 'skins/Belchertown/images/WxFeeds-warning-sign.png',
                                                  'skins/Belchertown/images/WxFeeds-weather-station.png'
                                                ]
                    )
                   ]
        )
