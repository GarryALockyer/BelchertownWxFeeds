//
//  WxFeeds Proxy Server
//
//  Garry Lockyer
//  Garry@lockyer.ca
//  C: +1.250.689.0686
//
//  This is intended to work with WeeWx and the belchertown skin.
//  It provides a proxy server to hide API keys and/or cache JSON data.
//
//  We create an https server to listen for several 'GET' requests.
//
//  Uses JWT to provide authentiation.  See WxFeedsAuthServer.
//

"use strict";

require("dotenv").config();

const express = require("express");
const https = require("https");
const fs = require("fs");
const jwt = require("jsonwebtoken");
const axios = require("axios");
const url = require("url");
const redis = require("redis");
const request = require("request");

const router = express.Router();
const app = express();

const REDIS_PORT = process.env.WX_FEEDS_REDIS_PORT;
const redisClient = redis.createClient(REDIS_PORT);

function authenticateToken(req, res, next) {
  console.log(`req.url: ${req.url}`);

  const query = url.parse(req.url, true).query;
  const token = query.accessToken;
  console.log(`token: ${token}`);

  if (token == null) return res.sendStatus(401);

  jwt.verify(token, process.env.WX_FEEDS_ACCESS_TOKEN_SECRET, (err, user) => {
    //console.log(`Token: ${token}`);

    if (err) return res.sendStatus(403);

    // Token is good!

    //console.log("Token Is Good!");

    next();
  });
}

app.use(express.json());

//  Handler to verify JWT token.

app.get("/verify", authenticateToken, (req, res) => {
  //console.log(req.url);

  res.send("Login Successful");
});

//  Handler(s) for GoogleMaps API request(s).

//  This handler uses a very convenient "request(newURL).pipe(res);"
//  to proxy requests.  This method is based on the request package
//  which has been deprecated.  It should be re-writtent to use axios

app.get("/GoogleMaps/maps", authenticateToken, (req, res) => {
  //console.log(`/GoogleMaps/maps URL: ${req.url}`);

  // The request was authenticated - make the call to Google Maps.

  const newURL =
    "https://maps.googleapis.com/maps/api/js?callback=initMap&key=" +
    process.env.WX_FEEDS_GOOGLE_MAPS_API_KEY;
  //console.log(`newURL: ${newURL}`);

  request(newURL).pipe(res);
});

app.get("/GoogleMaps/geocoding", authenticateToken, (req, res, next) => {
  //console.log(`/GoogleMaps/geocoding URL: ${req.url}`);

  // The request was authenticated - make the call to Google Maps.

  const query = url.parse(req.url, true).query;

  const address = query.address;
  //console.log(`address: ${address}`);
  const components = query.components;
  //console.log(`components: ${components}`);
  var forceCacheMiss = false;
  if (query.forceCacheMiss.toUpperCase() == "TRUE") {
    forceCacheMiss = true;
  }
  //console.log(`forceCacheMiss: ${forceCacheMiss}`);

  var cacheKey = address.replace(/ /g, "");
  cacheKey = cacheKey.replace(/,/g, "");
  cacheKey = cacheKey.replace(/'/g, "");
  cacheKey = "GoogleMapsGeocoding:" + cacheKey;
  //console.log(`cacheKey: ${cacheKey}`);

  const geocode = async () => {
    try {
      // Try to get the data from the cache.

      redisClient.get(cacheKey, async (err, cacheData) => {
        if (cacheData && forceCacheMiss == false) {
          //  Cache Hit - data was found in the cache so return it to the caller.

          return res.status(200).send(JSON.parse(cacheData));
        } else {
          //  Cache Miss - the data was not found in the cache so get it from the source.

          var geocodingURL =
            "https://maps.googleapis.com/maps/api/geocode/json?address=" +
            address;

          if (components) {
            geocodingURL += "&components=" + components;
          }

          geocodingURL += "&key=" + process.env.WX_FEEDS_GOOGLE_MAPS_API_KEY;
          //console.log(`geocodingURL: ${geocodingURL}`);

          try {
            const response = await axios.get(geocodingURL);

            //  We should have good data - cache it and return it to caller.

            const JSON_str = JSON.stringify(response.data);
            //console.log(`JSON_str.data: ${JSON_str}`);

            var expiry = parseInt(
              process.env
                .WX_FEEDS_GOOGLE_MAPS_GEOCODING_SERVICES_CACHE_EXPIRY_MINUTES
            );
            expiry *= 60;

            const expiry_str = expiry.toString();
            //console.log(`expiry: ${expiry}, expiry_str: ${expiry_str}`);

            redisClient.setex(cacheKey, BigInt(expiry_str), JSON_str);

            res.json(response.data);
          } catch (error) {
            if (error.response) {
              // The request was made and the server responded with a status code
              // that falls out of the range of 2xx.

              //console.log("error.response")
              //console.log(`error.response.data: ${error.response.data}`);
              console.log(`error.response.status: ${error.response.status}`);
              //console.log(`error.response.headers: ${error.response.headers}`);

              return res.status(error.response.status);
            } else if (error.request) {
              // The request was made but no response was received
              // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
              // http.ClientRequest in node.js
              //console.log("error.request");
              console.log(`error.request:)${error.request}`);
            } else {
              // Something happened in setting up the request that triggered an Error
              //console.log("error.message");
              console.log("error.message", error.message);

              return res.status(998);
            }
            console.log("error.config");
            console.log(`error.config: {error.config}`);

            return res.status(999);
          }
        }
      });
    } catch (error) {
      console.log(`redis error: ${error}`);

      return res.status(997);
    }
  };

  geocode();
});

app.get("/GoogleMaps/placesearch", authenticateToken, (req, res, next) => {
  //console.log(`/GoogleMaps/placesearch URL: ${req.url}`);

  // The request was authenticated - make the call to Google Maps.

  const query = url.parse(req.url, true).query;

  const input = query.input;
  //console.log(`input: ${input}`);
  var forceCacheMiss = false;
  if (query.forceCacheMiss.toUpperCase() == "TRUE") {
    forceCacheMiss = true;
  }
  //console.log(`forceCacheMiss: ${forceCacheMiss}`);

  var cacheKey = input.replace(/ /g, "");
  cacheKey = cacheKey.replace(/,/g, "");
  cacheKey = cacheKey.replace(/'/g, "");
  cacheKey = "GoogleMapsPlaceSearch:" + cacheKey;
  //console.log(`cacheKey: ${cacheKey}`);

  const placeSearch = async () => {
    try {
      // Try to get the data from the cache.

      redisClient.get(cacheKey, async (err, cacheData) => {
        if (cacheData && forceCacheMiss == false) {
          //  Cache Hit - data was found in the cache so return it to the caller.

          return res.status(200).send(JSON.parse(cacheData));
        } else {
          //  Cache Miss - the data was not found in the cache so get it from the source.

          const placeSearchURL =
            "https://maps.googleapis.com/maps/api/place/findplacefromtext/json" +
            "?inputtype=textquery" +
            "&input=" +
            input.replace(/ /g, "+") +
            "&fields=business_status,formatted_address,geometry,icon,name,plus_code,types" +
            "&key=" +
            process.env.WX_FEEDS_GOOGLE_MAPS_API_KEY;
          //console.log(`placeSearchURL: ${placeSearchURL}`);

          try {
            const response = await axios.get(placeSearchURL);

            //  We should have good data - cache it and return it to caller.

            const JSON_str = JSON.stringify(response.data);
            //console.log(`JSON_str.data: ${JSON_str}`);

            var expiry = parseInt(
              process.env
                .WX_FEEDS_GOOGLE_MAPS_GEOCODING_SERVICES_CACHE_EXPIRY_MINUTES
            );
            expiry *= 60;

            const expiry_str = expiry.toString();
            //console.log(`expiry: ${expiry}, expiry_str: ${expiry_str}`);

            redisClient.setex(cacheKey, BigInt(expiry_str), JSON_str);

            res.json(response.data);
          } catch (error) {
            if (error.response) {
              // The request was made and the server responded with a status code
              // that falls out of the range of 2xx.

              //console.log("error.response")
              //console.log(`error.response.data: ${error.response.data}`);
              console.log(`error.response.status: ${error.response.status}`);
              //console.log(`error.response.headers: ${error.response.headers}`);

              return res.status(error.response.status);
            } else if (error.request) {
              // The request was made but no response was received
              // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
              // http.ClientRequest in node.js
              //console.log("error.request");
              console.log(`error.request:)${error.request}`);
            } else {
              // Something happened in setting up the request that triggered an Error
              //console.log("error.message");
              console.log(`error.message: ${error.message}`);

              return res.status(998);
            }
            console.log(`error.config: ${error.config}`);

            return res.status(999);
          }
        }
      });
    } catch (error) {
      console.log(`redis error: ${error}`);

      return res.status(997);
    }
  };

  placeSearch();
});

//  Handler(s) for Air-Port-Codes API request(s).

router.get("/AirPortCodes/airport", authenticateToken, (req, res, next) => {
  //console.log(`/AirPortCodes/airport URL: ${req.url}`);

  const query = url.parse(req.url, true).query;

  const airport = query.iata;
  //console.log(`airport: ${airport}`);
  var forceCacheMiss = false;
  if (query.forceCacheMiss.toUpperCase() == "TRUE") {
    forceCacheMiss = true;
  }
  //console.log(`forceCacheMiss: ${forceCacheMiss}`);

  var cacheKey = airport.replace(/ /g, "");
  cacheKey = cacheKey.replace(/,/g, "");
  cacheKey = cacheKey.replace(/'/g, "");
  cacheKey = "AirPortCodesAirport:" + cacheKey;
  //console.log(`cacheKey: ${cacheKey}`);

  const getAirport = async () => {
    try {
      // Try to get the data from the cache.

      redisClient.get(cacheKey, async (err, cacheData) => {
        if (cacheData && forceCacheMiss == false) {
          //  Cache Hit - data was found in the cache so return it to the caller.

          return res.status(200).send(JSON.parse(cacheData));
        } else {
          //  Cache Miss - the data was not found in the cache so get it from the source.

          const key = process.env.WX_FEEDS_AIR_PORT_CODES_API_KEY;
          //console.log(`key: ${key}`);

          const secret = process.env.WX_FEEDS_AIR_PORT_CODES_API_SECRET;
          //console.log(`secret: ${secret}`);

          const airportURL =
            "https://www.air-port-codes.com/api/v1/single?iata=" +
            airport +
            "&key=" +
            key +
            "&secret=" +
            secret;
          //console.log(`airportURL: ${airportURL}`);

          try {
            const response = await axios.get(airportURL);

            //  We should have good data - cache it and return it to caller.

            const JSON_str = JSON.stringify(response.data);
            //console.log(`JSON_str.data: ${JSON_str}`);

            var expiry = parseInt(
              process.env.WX_FEEDS_NOAA_NWS_POINTS_CACHE_EXPIRY_MINUTES
            );
            expiry *= 60;

            const expiry_str = expiry.toString();
            //console.log(`expiry: ${expiry}, expiry_str: ${expiry_str}`);

            redisClient.setex(cacheKey, BigInt(expiry_str), JSON_str);

            res.json(response.data);
          } catch (error) {
            if (error.response) {
              // The request was made and the server responded with a status code
              // that falls out of the range of 2xx.

              //console.log("error.response")
              //console.log(`error.response.data: ${error.response.data}`);
              console.log(`error.response.status: ${error.response.status}`);
              //console.log(`error.response.headers: ${error.response.headers}`);

              return res.status(error.response.status);
            } else if (error.request) {
              // The request was made but no response was received
              // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
              // http.ClientRequest in node.js
              //console.log("error.request");
              console.log(`error.request:)${error.request}`);
            } else {
              // Something happened in setting up the request that triggered an Error
              console.log("error.message");
              console.log("Error", error.message);

              return res.status(998);
            }
            //console.log("error.config");
            console.log(`error.config: error.config}`);

            return res.status(999);
          }
        }
      });
    } catch (error) {
      console.log(`redis error: ${error}`);

      return res.status(997);
    }
  };

  getAirport();
});

//  Handler(s) for NOAA NWS API request(s).

//  For: https://api.weather.gov/points/{latitude},{longitude}

router.get("/NOAANWS/points", authenticateToken, (req, res, next) => {
  //console.log(`/NOAANWS/points URL: ${req.url}`);

  //const path = url.parse(req.url, true).path;

  const query = url.parse(req.url, true).query;

  const location = query.location;
  //console.log(`location: ${location}`);
  const latitude = query.latitude;
  //console.log(`latitude: ${latitude}`);
  const longitude = query.longitude;
  //console.log(`longitude: ${longitude}`);
  var forceCacheMiss = false;
  if (query.forceCacheMiss.toUpperCase() == "TRUE") {
    forceCacheMiss = true;
  }
  //console.log(`forceCacheMiss: ${forceCacheMiss}`);

  var cacheKey = location.replace(/ /g, "");
  cacheKey = cacheKey.replace(/,/g, "");
  cacheKey = cacheKey.replace(/'/g, "");
  cacheKey = "NOAANWSPoints:" + cacheKey;
  //console.log(`cacheKey: ${cacheKey}`);

  const getPoints = async () => {
    try {
      // Try to get the data from the cache.

      redisClient.get(cacheKey, async (err, cacheData) => {
        if (cacheData && forceCacheMiss == false) {
          //  Cache Hit - data was found in the cache so return it to the caller.

          return res.status(200).send(JSON.parse(cacheData));
        } else {
          //  Cache Miss - the data was not found in the cache so get it from the source.

          const pointsURL =
            "https://api.weather.gov/points/" +
            latitude.toString() +
            "," +
            longitude.toString();
          //console.log(`pointsURL: ${pointsURL}`);

          try {
            const response = await axios.get(pointsURL);

            //  We should have good data - cache it and return it to caller.

            const JSON_str = JSON.stringify(response.data);
            //console.log(`JSON_str.data: ${JSON_str}`);

            var expiry = parseInt(
              process.env.WX_FEEDS_NOAA_NWS_POINTS_CACHE_EXPIRY_MINUTES
            );
            expiry *= 60;

            const expiry_str = expiry.toString();
            //console.log(`expiry: ${expiry}, expiry_str: ${expiry_str}`);

            redisClient.setex(cacheKey, BigInt(expiry_str), JSON_str);

            res.json(response.data);
          } catch (error) {
            if (error.response) {
              // The request was made and the server responded with a status code
              // that falls out of the range of 2xx.

              //console.log("error.response")
              //console.log(`error.response.data: ${error.response.data}`);
              console.log(`error.response.status: ${error.response.status}`);
              //console.log(`error.response.headers: ${error.response.headers}`);

              return res.status(error.response.status);
            } else if (error.request) {
              // The request was made but no response was received
              // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
              // http.ClientRequest in node.js
              //console.log("error.request");
              console.log(`error.request:)${error.request}`);
            } else {
              // Something happened in setting up the request that triggered an Error
              console.log("error.message");
              console.log("Error", error.message);

              return res.status(998);
            }
            //console.log("error.config");
            console.log(`error.config: error.config}`);

            return res.status(999);
          }
        }
      });
    } catch (error) {
      console.log(`redis error: ${error}`);

      return res.status(997);
    }
  };

  getPoints();
});

//  Handler(s) for WS DOT Services.

app.get("/WSDOTServices/bordercrossings", authenticateToken, (req, res) => {
  //console.log(`/WSDOTServices/bordercrossings URL: ${req.url}`);

  // The request was authenticated - make the call to the WS DOT service.

  const newURL =
    "http://www.wsdot.com/Traffic/api/BorderCrossings/BorderCrossingsREST.svc" +
    "/GetBorderCrossingsAsJson?AccessCode=" +
    process.env.WX_FEEDS_WS_DOT_SERVICES_ACCESS_CODE;
  //console.log(`newURL: ${newURL}`);

  request(newURL).pipe(res);
});

const port = process.env.WX_FEEDS_PROXY_SERVER_PORT;
const keyFile = process.env.WX_FEEDS_KEY_FILE;
const certFile = process.env.WX_FEEDS_CERT_FILE;

//  Standard listener.  Kept in case we need to debug using http.
//app.listen( PORT )

//  Create an https server.

app.use("/", router);

https
  .createServer(
    {
      key: fs.readFileSync(keyFile),
      cert: fs.readFileSync(certFile),
    },
    app
  )
  .listen(port, function (err) {
    if (err) {
      console.log(
        "There was an error starting the WxFeedsProxyServer!  Err: ",
        err
      );
      return;
    }

    console.log(`WxFeedsProxyServer listening on port ${port}.`);
  });
