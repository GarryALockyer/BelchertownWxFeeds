//
//  WxFeeds Authentication Server
//
//  Garry Lockyer
//  Garry@lockyer.ca
//  C: +1.250.689.0686
//
//  This is intended to work with WeeWx and the belchertown skin.
//  It provides authentication which can then be used to access
//  a WxFeedsProxyServer.
//
//  This is all part of a proxy server solution to hide API keys.
//
//  Create an https server to listen for 'login' requests.
//
//  Supplied credentials are authenticated against credential environment variables.
//
//  The username (WX_FEEDS_USERNAME) is stored in plain text.
//  The password (WX_FEEDS_PASSWORD) is stored as a bcrypt hash.
//
//  Use a service such as https://passwordhashing.com/BCrypt to generate
//  a hashed password (to be stored as an environment variable).
//
//  WX_FEEDS_ACCESS_TOKEN_SECRET was generated using node command:
//
//      require('crypto').randomBytes(64).toString('hex')
//

"use strict";

require("dotenv").config();

const express = require("express");
const https = require("https");
const fs = require("fs");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const app = express();

app.use(express.json());

app.post("/login", async (req, res) => {
  //  Authenticate the user.

  const username = process.env.WX_FEEDS_USERNAME;
  const password = process.env.WX_FEEDS_PASSWORD;

  var userAuthenticated = false;

  if (
    username == null ||
    username == "" ||
    password == null ||
    password == ""
  ) {
    return res.status(400).send("Cannot find user and/or password!");
  }

  if (req.body.username === username) {
    try {
      if ((await bcrypt.compare(req.body.password, password)) == true) {
        userAuthenticated = true;
      } else {
        return res.send("Login Failed");
      }
    } catch {
      return res.status(500).send("bcrypt exception!");
    }
  } else {
    return res.send("Usernames do not match!");
  }

  if (userAuthenticated == true) {
    //  The user has been authenticated - send them an access token.

    const user = { name: username };

    const accessToken = jwt.sign(
      user,
      process.env.WX_FEEDS_ACCESS_TOKEN_SECRET, { expiresIn: process.env.WX_FEEDS_TOKEN_EXPIRY_SECONDS * 1000 }
    );

    res.json({ loginStatus: "Login Successful", accessToken: accessToken, tokenExpiry: process.env.WX_FEEDS_TOKEN_EXPIRY_SECONDS });
  }
});

const port = process.env.WX_FEEDS_AUTHORIZATION_SERVER_PORT;
const keyFile = process.env.WX_FEEDS_KEY_FILE;
const certFile = process.env.WX_FEEDS_CERT_FILE;

//  Standard listener.  Kept in case we need to debug using http.
//app.listen( PORT )

//  Create an https server.

https
  .createServer(
    {
      key: fs.readFileSync(keyFile),
      cert: fs.readFileSync(certFile),
    },
    app
  )
  .listen(port, function (err) {
    if (err) {
      console.log(
        "There was an error starting the WxFeedsAuthServer!  Err: ",
        err
      );
      return;
    }

    console.log(`WxFeedsAuthServer listening on port ${port}.`);
  });
